# gRPC Objective-C Mac OS Hello World Example

A hello world example app on Mac OS. Note that Mac OS is not a first class supported platform of gRPC
Objective-C library. This example is only for reference.

Refer to [Hello World Example](../helloworld) for instructions on installation and running.
